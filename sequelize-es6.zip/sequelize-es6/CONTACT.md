## Contact Us

In some cases you might want to reach the maintainers privately. These can be reporting a security vulnerability or any other specific cases. 
You can use the information below to contact maintainers directly. We will try to get back to you as soon as possible.

### Via Email

- **Mick Hansen** mick.kasper.hansen@gmail.com
- **Jan Aagaard Meier** janzeh@gmail.com
- **Sushant Dhiman** sushantdhiman@outlook.com

### Via Slack

Maintainer's usernames for [Sequelize Slack Channel](https://sequelize.slack.com)

- **Mick Hansen** @mhansen
- **Jan Aagaard Meier** @janmeier
- **Sushant Dhiman** @sushantdhiman 




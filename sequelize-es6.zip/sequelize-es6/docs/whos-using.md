# Who's using sequelize?

[![Walmart labs logo](asset/walmart-labs-logo.png)](http://www.walmartlabs.com/)
> ... we are avid users of sequelize (and have been for the past 18 months) (Feb 2017)

[![Snaplytics logo](asset/logo-snaplytics-green.png)](https://snaplytics.io)

> We've been using sequelize since we started in the beginning of 2015. We use it for our graphql servers (in connection with [graphql-sequelize](github.com/mickhansen/graphql-sequelize)), and for all our background workers.

[![Connected Cars logo](asset/connected-cars.png)](https://connectedcars.dk/)
